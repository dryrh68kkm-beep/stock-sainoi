#!/usr/bin/env python3
# สร้าง data/packmap.js จาก data/multI_SV.csv
# วิธีใช้:  python3 build_packmap.py
import csv, json, re, os

HERE=os.path.dirname(os.path.abspath(__file__))
SRC=os.path.join(HERE,'data','multI_SV.csv')
OUT=os.path.join(HERE,'data','packmap.js')

def normBc(s):
    s=str(s or '').strip()
    if re.search(r'[eE]\+?\d+', s.replace(',','')): return ''   # scientific notation = เพี้ยน
    s=re.sub(r'[^0-9]','',s); s=re.sub(r'^0+(?=\d)','',s); return s

def norm(x):
    return str(x or '').strip().replace(' ','').replace('\xa0','').lower()

def read_rows(path):
    for enc in ('utf-8-sig','cp874','utf-8'):
        try:
            return list(csv.reader(open(path,encoding=enc)))
        except Exception:
            continue
    raise SystemExit('อ่านไฟล์ไม่ได้: '+path)

rows=read_rows(SRC)[1:]
packmap={}; packByName={}
for r in rows:
    if len(r)<11: continue
    packBc=normBc(r[5]); singleBc=normBc(r[7])
    try: qty=int(float(r[10]))
    except: qty=0
    if qty<=0: continue
    sn=r[9].strip(); pn=r[6].strip()
    info={'s':singleBc,'q':qty,'sn':sn,'pn':pn}
    if packBc: packmap[packBc]=info
    pnn=norm(pn)
    if pnn and pnn not in packByName: packByName[pnn]=info

out={'byBc':packmap,'byName':packByName}
with open(OUT,'w',encoding='utf-8') as f:
    f.write('window.PACKMAP='+json.dumps(out,ensure_ascii=False,separators=(',',':'))+';')

print('สร้าง packmap.js สำเร็จ')
print('  by barcode:',len(packmap))
print('  by name   :',len(packByName))
print('  ไฟล์:',OUT)
